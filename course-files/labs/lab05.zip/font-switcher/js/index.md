---
layout: default
title: Js
nav_exclude: True
---

# Js

[course-files/labs/lab04/font-switcher/js/](.)

<table class="tbl-files">
    <tbody>
        <tr>
            <th valign="top"></th>
            <th>Name</th>
            <th>Last modified</th>
            <th>Size</th>
            <th>Preview</th>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder-open"></i>
            </td>
            <td><a href="../">Parent Directory</a></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>

        <tr class="click-to-preview">
            <td class="first-column">
                    <i class="far fa-file"></i>
            </td>
            <td nowrap>
                    <a href="index.js">index.js</a>
            </td>
            <td align="right">4/24/2019 11:28 PM</td>
            <td>223.0B</td>
            <td>
                    <a href="https://github.com/eecs130/spring2019/blob/master/course-files/labs/lab04/font-switcher/js/index.js"
                        target="_blank"><i class="fab fa-github fa-lg"></i></a>
            </td>
        </tr>
    </tbody>
</table>

