---
layout: default
title: Css
nav_exclude: True
---

# Css

[course-files/labs/lab04/font-switcher/css/](.)

<table class="tbl-files">
    <tbody>
        <tr>
            <th valign="top"></th>
            <th>Name</th>
            <th>Last modified</th>
            <th>Size</th>
            <th>Preview</th>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder-open"></i>
            </td>
            <td><a href="../">Parent Directory</a></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>

        <tr class="click-to-preview">
            <td class="first-column">
                    <i class="far fa-file"></i>
            </td>
            <td nowrap>
                    <a href="style.css">style.css</a>
            </td>
            <td align="right">4/25/2019 4:22 AM</td>
            <td>1.3KB</td>
            <td>
                    <a href="https://github.com/eecs130/spring2019/blob/master/course-files/labs/lab04/font-switcher/css/style.css"
                        target="_blank"><i class="fab fa-github fa-lg"></i></a>
            </td>
        </tr>
    </tbody>
</table>

