---
layout: default
title: Theme Switcher
nav_exclude: True
---

# Theme Switcher

[course-files/labs/lab04/theme-switcher/](.)

<table class="tbl-files">
    <tbody>
        <tr>
            <th valign="top"></th>
            <th>Name</th>
            <th>Last modified</th>
            <th>Size</th>
            <th>Preview</th>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder-open"></i>
            </td>
            <td><a href="../">Parent Directory</a></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>

        <tr>
            <td valign="top">
                <i class="fa fa-folder"></i>
            </td>
            <td><a href="css">css</a></td>
            <td align="right">4/25/2019 8:38 AM</td>
            <td>128.0B</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td valign="top">
                <i class="fa fa-folder"></i>
            </td>
            <td><a href="js">js</a></td>
            <td align="right">4/25/2019 8:38 AM</td>
            <td>128.0B</td>
            <td>&nbsp;</td>
        </tr>
        <tr class="click-to-preview">
            <td class="first-column">
                    <i class="far fa-file"></i>
            </td>
            <td nowrap>
                    <a href="index0.html">index0.html</a>
            </td>
            <td align="right">4/25/2019 8:35 AM</td>
            <td>489.0B</td>
            <td>
                    <a href="https://github.com/eecs130/spring2019/blob/master/course-files/labs/lab04/theme-switcher/index0.html"
                        target="_blank"><i class="fab fa-github fa-lg"></i></a>
            </td>
        </tr>
    </tbody>
</table>

