import React from 'react';

class DoctorDetailView extends React.Component {

    render () {
        return ( 
            <div className="doctor">
                <h2>Current Doctor</h2>
                <p>Current doctor goes here</p>
            </div>
        ) 
    }
}

export default DoctorDetailView;