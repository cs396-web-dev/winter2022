// useful reference: https://reactjs.org/docs/faq-ajax.html
import React from 'react';

class DoctorList extends React.Component {
  
    render () {
        return (
            <aside className="aside">
                List of doctors goes here.
            </aside>
        );
    }
}

export default DoctorList;