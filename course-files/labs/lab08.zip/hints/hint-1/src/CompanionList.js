import React from 'react';

class CompanionList extends React.Component {
    
    constructor(props) {
        super(props);
        // initialization code
    }

    render () {
        return (
            <section className="companions">
                <h2>Companions</h2>
                <p>Companions go here</p>
            </section>
        );
    }
}

export default CompanionList;