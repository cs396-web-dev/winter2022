/**
 * Edit the processDelete() function body
 * so that it issues a DELETE request to the
 * server with the ID corresponding to the ID in the form
 */

const processDelete = ev => {
    // your code here:




    // don't forget to prevent the default
    // submit button behavior from firing:
    ev.preventDefault();
};

document.querySelector('button').onclick = processDelete;