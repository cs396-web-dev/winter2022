
/* Implement the listPrint and fibonacci functions below: */

function listPrint(arr) {

}

function fibonacci(n) {

}

/* below you will find the function calls and expected output: */

listPrint(["line1", "line2", "line3"]);
/*
Expected output:
line1
line2
line3
*/

console.log(fibonacci(9));

/*
Expected output:
[ 0,  1,  1,  2,  3,  5,  8, 13, 21 ]
*/
